from sys import exit

# ------------------------ VARIABLES ------------------------
#Global variables which can be changed according to user preferences. Used throughout the code.
po_alive = True
goblin_alive = True
dagger = False

# ---------------------- ROUTINES ----------------------

# ROOM 1
#STARTING SEQUENCE FOR GAME, ROOM 1 OR OPENING ROOM IS DEFINED.
def room_1():
    print ("You are in a big room with greasy black walls.")
    print ("It's pitch black but you make out three corridors.")
    print ("They lead east, north and west. Which way do you go?")
#Gives the user a choice to decide which passage to take.
    choice = input("> ");
#User input choice and either is greeted with another room (function) or the gameover function is called.
    if "west" in choice:
        room_2()
    elif "north" in choice:
        room_4()
    elif "east" in choice:
        game_over(""""You carefully go through the narrow corridor heading east.
After walking for 10 minutes, you see that you're at a dead end.
You turn around to go back but you find yourself facing another wall
Without water nor food, you die some days later.
The last thing you think of is the slice of cheesecake left in your fridge""")
    else:
        room_1()
#Used in case an invalid input is entered so the user sees the opening room text once again.
# ROOM 2
#IF PLAYER ENTERS WEST FROM ROOM 1 THEY ARRIVE IN ROOM 2 AND HAVE A CHOICE WHICH PASSAGE TO TAKE.
def room_2():
    print ("You enter another room it has a really low ceiling and you crawl to move")
    print ("You see a passage leading west and a passage leading north.")
    print ("Blood splatters against the walls of the North passage and you hear a sound calling your name from deep within.")
    print ("From the second one, the smell of death fills the room and your curiosity draws you to the west passage.")
    print ("The passage to the east leads to the first room filled with nothing but memories.")
    print ("What do you do?")
#Gives the user a choice to decide which passage to take.
    choice = input(">");
#User inputs West passage and is greeted by gameover text and the option to either restart or exit the game.
    if "west" in choice:
        game_over("""You follow the western passage As you walk, the smell gets more portent, until you can't bear it anymore.
Suddenly you can no longer smell the odour anymore
A soft hiss escapes from the walls and the odour comes back stronger than ever.
he odour fill your nostrils and you collpase gagging to the ground slowly choking on your last breaths. You die a painful and slow death.""")
#User inputs North passage and proceeds to room3.
    elif "north" in choice:
        room_3()
#User inputs East passage and is returned back to the starting room.        
    elif "east" in choice:
        room_1()
#Used in case an invalid input is entered so the user sees the opening room text once again.        
    else:
        room_2()

# ROOM 3
#Defining room 3 to be used globally.
def room_3():
#Tests if the global predefined variables are set to True or False and executes according to the result.
    global po_alive
    global dagger
#If po_alive is set to true the following text is displayed.
    if po_alive:
        print ("As you walk into the room, you understand where the smell came from.")
        print ("The floor is littered with rotting corpses.")
        print ("Suddenly you hear a growl and Po from Kung Fu Panda appears in front of you shouting in Japanese!.")
        print ("You see a passage to the east, a flaming keyboard lies on the ground code is spewed from it with every key press.")
        print ("A lone manhole is on the western side of the room and spikes to seem to protrout from it.")
        print ("The passage to the south leads to the second room.")
        print ("As you gaze around the room you see a dagger glistening with cold fury just in front of you")
        print ("What do you do?")
#Gives the user a choice to decide which passage to take.
        choice = input("> ")
#User inputs East passage and is greeted by gameover text and the option to either restart or exit the game.
        if "east" in choice:
            game_over("""As you run towards the east passage, Po jumps onto
 you. You don't have the time to react,
and within a second Po has flattened you into a pancake.""")
#User enters keyboard and defeats Po setting the variable to false for future play, before being transported to room 3.
        elif "keyboard" in choice:
            print ("""You quickly jump towards the keyboard grabbing it and and point it towards Po.
You quickly conjure a ransomware virus and force Po to pay the fee to unlock his brain.
He doesent have the funds to pay and stays trapped in his own mind forever!""")
            po_alive = False
            room_3()
        elif "dagger" in choice:
            print ("""You take the Dagger. Suddenly, it starts emanating a faint
glow and you feel invincible. Without knowing how,it starts to control your movements.
Like a videogame combo you swiftly decapitate Po and end his reign of terror""")
            po_alive = False
            dagger = True
            room_3()
# User inputs hole and is greeted by gameover text and the option to either restart or exit the game.
        elif "manhole" in choice:
            game_over("""You jump into the dark manhole cuttting yourself to pieces as you do so.
you make it through the hole only to fall through into the void
never again hitting a floor. You fall until you slowly bleed to death suffering the whole time.""")
 #User inputs west and is greeted by the same text that is displayed if hole is entered, the option to restart or exit the game.             
        elif "west" in choice:
            game_over("""You jump into the dark manhole cuttting yourself to pieces as you do so.//
//you make it through the hole only to fall through into the void
never again hitting a floor. You fall until you slowly bleed to death suffering the whole time.""")
#Used in case an invalid input is entered so the user sees the opening room text once again.            
        elif "south" in choice:
            room_2()
#Alternate path according to whether po_alive, gremlin_alive and dagger are set to true or false.            
        else:
            room_3()

    else:
        print ("The floor is littered with rotting corpses.")
        print ("You see a passage to the east, a flaming torch on the ground,")
        print ("a zombie holding a sword and a hole on the far side of the room.")
        print ("The passage to the south leads to the second room.")
        print ("What do you do?")
#Gives the user a choice to decide which passage to take.
        choice = input("> ")
#User inputs east passage and is transported back to room 4.
        if "east" in choice:
            room_4()
#User inputs keyboard and is greeted by text and moved to room 3.             
        elif "torch" in choice:
            print ("""You take the flaming torch and wave it in the air.
You feel stupid and put it down.""")
            room_3()
#User inputs dagger and is greeted by text and moved to room 3.               
        elif "dagger" in choice:
            print ( "You take the dagger.")
            sword = True
            room_3()
#User inputs hole and is greeted by gameover text and given the option to exit or restart the game.             
        elif "manhole" in choice:
            game_over("""You jump in the dark. It wasn't
such a good idea, though. You start falling in the void,
never again hitting a floor. You die days later, still
falling.""")
        elif "south" in choice:
            room_2()
        else:
            room_3()

# ROOM 4
#Defining the global variable room 4.
def room_4():
#Calling the variable gremlin_alive to see if True or False.
    global goblin_alive
#Checks to see if the variable is set to True.
    if goblin_alive:
#If variable is true prints text.
        print ("The room is huge and scattered with bones in it lives a Goblin.")
#If dagger variable is true pronts text and sets gremlin_alive to false for future play. Transports user to room 4.
        if dagger:
            print (""""Suddenly your dagger starts to glow. You experience a clear knowledge and voice which urges you to
leap forward and tackle the Goblin. You grapple with the goblin until you grab your sword and plunge it deep into the gremblin
It dies with horribe pained screams.""")
            goblin_alive = False
            room_4()
#If gremlin_alive and sword are set to False executes alternative decision path            
        else:
            print ("There is a passage to the north, one to the east, one to the")
            print ("south and one to the west. What do you do?")
#Gives the user a choice to decide which passage to take.
        choice = input("> ")
#Considers all Inputs and gives the game over message giving the user the option to either exit or restart the game.
        game_over("The Goblin leaps in front of you and shreds you like cheese with its claws.")
#Checks to see if global variables are True if not executes alternative path
    else:
        print ("There is a passage to the north, one to the east, one to the")
        print ("south and one to the west. What do you do?")
#Gives the user a choice to decide which passage to take.
        choice = input("> ")
#User inputs East and is greeted by gameover text and given the option to either exit or restart the game.
        if "east" in choice:
            game_over("""You follow the east passage until you end up in a study
room with a gaming pc and desk. You see Kim Jong UN in the screen and begin typing
 he notices your presence. With a grunt he says 'You should
not have found me I DECLARE WAR!' 'Now
you have to die.' He types something on the PC, and a nuclear missle is sent to America he then turns to you and you spontaneously combust..""")
#User inputs south and is moved to room 1.               
        elif "south" in choice:
            room_1()
#User inputs west and is moved to room 3.            
        elif "west" in choice:
            room_3()
        elif "north" in choice:
            game_over(""""The passage leads to the surface. You are free! Owen Ma's hand extends to the light you take it and
escape the torture that awaited you""")
        else:
            room_4()

# START
#Defines start as a global variable and sets room 1 as the starting room.
def start():
    room_1()

# GAME OVER
#Defines gameover as a global variable.
def game_over(s):
#Calls all of the other global variables when game_over is called.
    global po_alive
    global goblin_alive
    global dagger
#Sets all global variables to True except for dagger for different story (CAN BE CHANGED ACCORDING TO PREFERENCES)
    po_alive = True
    goblin_alive = True
    dagger = False
#Displays the following to the user after game_over function is called.
    print (s)
    print ("Do you want to play again? (y / n)")
#if user inputs yes or y start() is called and the program restarted.
    choice = ""
    while choice != "y" and choice != "n":
        choice = input("> ")
        if choice == "y":
#if user inputs n sys.exit is executed and the program closed.
            start()
        elif choice == "n":
            exit(0)


# --------------------------- MAIN ---------------------------

start()
