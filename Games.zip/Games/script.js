//2048 Main Code Made by Blake and Brandon

/* The below variables are defined and used later in the main program, the first variable defines and the canvas block
which was previously made in the index.html file. The canvas is then set to 2d and the size label and score are all called
from the original index.html file. After all the variables have been called and imported the score is set to 0 and the size
of the canvas block set again in case of error.
*/
var canvas = document.getElementById('canvas');
var ctx = canvas.getContext('2d');
var sizeInput = document.getElementById('size');
var changeSize = document.getElementById('change-size');
var scoreLabel = document.getElementById('score');
var score = 0;
var size = 4;
var width = canvas.width / size - 6;
var cells = [];
var fontSize;
var loss = false;

//Begins the Game
startGame();

/*
This function is related to a user input which is a mouse click, once the user clicks the canvas is cleared
and the width and size of the canavs are created according to the size the user enters, only sizes between 2 and 20 are accepted
as valid.
 */
changeSize.onclick = function () {
    if (sizeInput.value >= 2 && sizeInput.value <= 20) {
        size = sizeInput.value;
        width = canvas.width / size - 6;
        console.log(sizeInput.value);
        canvasClean();
        startGame();
    }
}
//This function is used to create all cells and define the width and size of the cell columns according to the size the user inputted.
function cell(row, coll) {
    this.value = 0;
    this.x = coll * width + 5 * (coll + 1);
    this.y = row * width + 5 * (row + 1);
}
//After the cell size is defined and entered this function begins to draw the cells according to user input.
function createCells() {
    var i, j;
    for(i = 0; i < size; i++) {
        cells[i] = [];
        for(j = 0; j < size; j++) {
            cells[i][j] = new cell(i, j);
        }
    }
}
/*
The following function is used to colour in all cells according to their value, the rgb values are enetered to assign specific colours
to certain number e.g  256 = Dark Blue
 */
function drawCell(cell) {
    ctx.beginPath();
    ctx.rect(cell.x, cell.y, width, width);
    switch (cell.value){
        case 0 : ctx.fillStyle = '#A9A9A9'; break;
        case 2 : ctx.fillStyle = '#D2691E'; break;
        case 4 : ctx.fillStyle = '#FF7F50'; break;
        case 8 : ctx.fillStyle = '#ffbf00'; break;
        case 16 : ctx.fillStyle = '#bfff00'; break;
        case 32 : ctx.fillStyle = '#40ff00'; break;
        case 64 : ctx.fillStyle = '#00bfff'; break;
        case 128 : ctx.fillStyle = '#FF7F50'; break;
        case 256 : ctx.fillStyle = '#0040ff'; break;
        case 512 : ctx.fillStyle = '#ff0080'; break;
        case 1024 : ctx.fillStyle = '#86FF33'; break;
        case 2048 : ctx.fillStyle = '#33FFC4'; break;
        case 4096 : ctx.fillStyle = '#3368FF'; break;
        default : ctx.fillStyle = '#ff0080';
    }
   //This fills all cells with the assigned colour as well as assigning the relevant integer value to the specific cell.
    ctx.fill();
    if (cell.value) {
        fontSize = width/2;
        ctx.font = fontSize + 'px Arial';
        ctx.fillStyle = 'white';
        ctx.textAlign = 'center';
        ctx.fillText(cell.value, cell.x + width / 2, cell.y + width / 2 + width/7);
    }
}
//This function is used to clear the canvas and is called at either the start or end of a game.
function canvasClean() {
    ctx.clearRect(0, 0, 500, 500);
}
/*
This function is used in the event of when a user inputs the down key as their selection, the else statements are used to see
if the logic is right and if there is a valid move, if the move is valid the move will be executed and the users score will rise
as a result of the move.
 */
document.onkeydown = function (event) {
    if (!loss) {
        if (event.keyCode === 38 || event.keyCode === 87) {
            moveUp();
        } else if (event.keyCode === 39 || event.keyCode === 68) {
            moveRight();
        } else if (event.keyCode === 40 || event.keyCode === 83) {
            moveDown();
        } else if (event.keyCode === 37 || event.keyCode === 65) {
            moveLeft();
        }
        scoreLabel.innerHTML = 'Score : ' + score;
    }
}
//This function starts the actual game whilst clearing the canvas, drawing all cells and generating random cells which allows the user to initiate the game.
function startGame() {
    createCells();
    drawAllCells();
    pasteNewCell();
    pasteNewCell();
}
//This Function is ued in the event of an invalid move or loss and causes the canvas to go grey and indicate to the user that they have no possible moves left.
function finishGame() {
    canvas.style.opacity = '0.5';
    loss = true;
}
//This defines the creation of a new random cell to be used later with a random integer.
function drawAllCells() {
    var i, j;
    for(i = 0; i < size; i++) {
        for(j = 0; j < size; j++) {
            drawCell(cells[i][j]);
        }
    }
}
//This functions pastes the newly created cell with a random integer either 2 or 4 on a random open position on the canvas.
function pasteNewCell() {
    var countFree = 0;
    var i, j;
    for(i = 0; i < size; i++) {
        for(j = 0; j < size; j++) {
            if(!cells[i][j].value) {
                countFree++;
            }
        }
    }
   //Checking is the board is full or has available spaces.
    if(!countFree) {
        finishGame();
        return;
    }
  //If the canvas is free it assigns a random integer and pastes a new cell in a random position.
    while(true) {
        var row = Math.floor(Math.random() * size);
        var coll = Math.floor(Math.random() * size);
        if(!cells[row][coll].value) {
            cells[row][coll].value = 2 * Math.ceil(Math.random() * 2);
            drawAllCells();
            return;
        }
    }
}
/*
This function is used in the event of when a user inputs the right key as their selection, the else/if/while statements are used to see
if the logic is right and if there is a valid move, if the move is valid the move will be executed and the users score will rise
as a result of the move according to the integer in which they have combined.
 */
function moveRight () {
    var i, j;
    var coll;
    for(i = 0; i < size; i++) {
        for(j = size - 2; j >= 0; j--) {
            if(cells[i][j].value) {
                coll = j;
                while (coll + 1 < size) {
                    if (!cells[i][coll + 1].value) {
                        cells[i][coll + 1].value = cells[i][coll].value;
                        cells[i][coll].value = 0;
                        coll++;
                    } else if (cells[i][coll].value == cells[i][coll + 1].value) {
                        cells[i][coll + 1].value *= 2;
                        score +=  cells[i][coll + 1].value;
                        cells[i][coll].value = 0;
                        break;
                    } else {
                        break;
                    }
                }
            }
        }
    }
    pasteNewCell();
}
/*
This function is used in the event of when a user inputs the Left key as their selection, the else/if/while statements are used to see
if the logic is right and if there is a valid move, if the move is valid the move will be executed and the users score will rise
as a result of the move according to the integer in which they have combined.
 */
function moveLeft() {
    var i, j;
    var coll;
    for(i = 0; i < size; i++) {
        for(j = 1; j < size; j++) {
            if(cells[i][j].value) {
                coll = j;
                while (coll - 1 >= 0) {
                    if (!cells[i][coll - 1].value) {
                        cells[i][coll - 1].value = cells[i][coll].value;
                        cells[i][coll].value = 0;
                        coll--;
                    } else if (cells[i][coll].value == cells[i][coll - 1].value) {
                        cells[i][coll - 1].value *= 2;
                        score +=   cells[i][coll - 1].value;
                        cells[i][coll].value = 0;
                        break;
                    } else {
                        break;
                    }
                }
            }
        }
    }
    pasteNewCell();
}
/*
This function is used in the event of when a user inputs the Up key as their selection, the else/if/while statements are used to see
if the logic is right and if there is a valid move, if the move is valid the move will be executed and the users score will rise
as a result of the move according to the integer in which they have combined.
 */
function moveUp() {
    var i, j, row;
    for(j = 0; j < size; j++) {
        for(i = 1; i < size; i++) {
            if(cells[i][j].value) {
                row = i;
                while (row > 0) {
                    if(!cells[row - 1][j].value) {
                        cells[row - 1][j].value = cells[row][j].value;
                        cells[row][j].value = 0;
                        row--;
                    } else if (cells[row][j].value == cells[row - 1][j].value) {
                        cells[row - 1][j].value *= 2;
                        score +=  cells[row - 1][j].value;
                        cells[row][j].value = 0;
                        break;
                    } else {
                        break;
                    }
                }
            }
        }
    }
    pasteNewCell();
}
/*
This function is used in the event of when a user inputs the Down key as their selection, the else/if/while statements are used to see
if the logic is right and if there is a valid move, if the move is valid the move will be executed and the users score will rise
as a result of the move according to the integer in which they have combined.
 */
function moveDown() {
    var i, j, row;
    for(j = 0; j < size; j++) {
        for(i = size - 2; i >= 0; i--) {
            if(cells[i][j].value) {
                row = i;
                while (row + 1 < size) {
                    if (!cells[row + 1][j].value) {
                        cells[row + 1][j].value = cells[row][j].value;
                        cells[row][j].value = 0;
                        row++;
                    } else if (cells[row][j].value == cells[row + 1][j].value) {
                        cells[row + 1][j].value *= 2;
                        score +=  cells[row + 1][j].value;
                        cells[row][j].value = 0;
                        break;
                    } else {
                        break;
                    }
                }
            }
        }
    }
    pasteNewCell();
}
score.push({name:"user",score:theScore,date:new Date().valueOf()});
localStorage["theGameName_HighScores"] = JSON.stringify(scores); // done all saved on the client machine
// you can also use dot notation
localStorage.theGameName_HighScores = JSON.stringify(scores); // done all saved on the client machine
//To get the scores back
if(localStorage["theGameName_HighScores"] !== undefined){ // check if the storage exists
    scores = JSON.parse(localStorage["theGameName_HighScores"]);
}else{
    scores = []; // empty score array;
}